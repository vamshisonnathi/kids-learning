# MathQuest: 5th Grade Adaptive Math Platform - PRD

## Original Problem Statement
Build Phase 1 prototype of a 5th-grade adaptive math platform featuring:
- Student Dashboard: "Learning Map" visualizing skill graph as adventure/treasure map
- Teacher View: Data-dense table with mastery scores and error patterns
- Database: Store 20 TEKS skill nodes, prerequisites, and student mastery progress
- Role-Based Access Control (RBAC) with 5 roles: Student, Teacher, Parent, Admin, Sales
- STAAR Gap Finder diagnostic flow as onboarding experience

## Architecture
- **Backend**: FastAPI (Python) with PostgreSQL (SQLAlchemy)
- **Frontend**: React with Tailwind CSS, Shadcn UI, react-router-dom v7
- **Database**: PostgreSQL (Supabase) with asyncpg + pgbouncer
- **AI**: Anthropic Claude Haiku 4.5 via Emergent LLM Key (tutoring, problem generation)
- **Image Gen**: OpenAI GPT Image 1 via Emergent LLM Key (problem illustrations)

### Frontend Architecture
```
/app/frontend/src/
├── App.js                    # Router with AuthProvider + ProtectedRoute
├── lib/api.js                # Centralized API helper
├── contexts/AuthContext.jsx  # Auth state, roles, permissions
├── components/
│   ├── LoginPage.jsx         # Role selection + student picker
│   ├── ProtectedRoute.jsx    # Route guard
│   ├── StudentHome.jsx       # STAAR diagnostic welcome screen
│   ├── DiagnosticFlow.jsx    # 5-question diagnostic test UI
│   ├── StudentMap.jsx        # Adventure map (with diagnostic overlay)
│   ├── PracticeModal.jsx     # Socratic tutor chat (shows images)
│   ├── TeacherDashboard.jsx  # Class overview
│   ├── TeacherStudentDetail.jsx
│   ├── layouts/
│   │   ├── StudentLayout.jsx  # Nav: Home | Diagnostic | Map
│   │   ├── TeacherLayout.jsx
│   │   ├── ParentLayout.jsx
│   │   ├── AdminLayout.jsx
│   │   └── SalesLayout.jsx
│   └── ui/                   # Shadcn components
└── pages/
    ├── ParentHome.jsx        # Child progress, skill breakdown
    ├── AdminHome.jsx         # System overview, content management
    └── SalesHome.jsx         # Pipeline, district licensing
```

### Student Routes
- `/student/home` — STAAR welcome screen with diagnostic CTA
- `/student/diagnostic` — 5-question diagnostic flow (N01,N04,N05,N15,N17)
- `/student/map` — Adventure map (accepts diagnostic results via location state)

## What's Been Implemented

### Phase 1-5 (Foundation through Problem Generation)
- [x] Backend API with 15+ endpoints
- [x] PostgreSQL data models (migrated from MongoDB)
- [x] Student adventure map, Teacher dashboard
- [x] Socratic tutor with Claude Haiku 4.5
- [x] LLM-powered problem generation
- [x] Image generation (OpenAI GPT Image 1)

### Phase 6 - RBAC + Portals (March 2026)
- [x] 5-role RBAC with AuthContext, ProtectedRoute, dedicated layouts
- [x] Parent Portal: Child mastery overview + skill breakdown
- [x] Admin Portal: System status + Content Management (Generate Problems/Images)
- [x] Sales Portal: District pipeline + upcoming demos (MOCK data)

### Phase 7 - STAAR Diagnostic Flow (March 2026)
- [x] StudentHome welcome screen at /student/home
- [x] DiagnosticFlow: 5-question test UI (no chat modal)
- [x] Progress bar, question dots, correct/incorrect flash feedback
- [x] Auto-navigate to map with results after 5th question
- [x] Map: diagnostic-gap nodes pulse red with "Start Here!" labels
- [x] Map: banner shows "Diagnostic Complete - X/5 correct"
- [x] StudentLayout nav updated: Home | Diagnostic | Map

## Key API Endpoints
- `POST /api/tutor/evaluate` - Socratic tutoring with LLM
- `POST /api/problems/generate` - AI problem generation
- `POST /api/problems/{id}/generate-image` - Single image generation
- `POST /api/problems/generate-images-batch` - Batch image generation
- `GET /api/tutor/problem/{node_id}` - Get practice problem (used by diagnostic)
- `GET /api/teacher/dashboard` - Teacher class overview
- `GET /api/teacher/student/{id}/detail` - Student detail with skills
- `GET /api/students` - List all students
- `GET /api/skill-graph` - Skill DAG structure

## Prioritized Backlog

### P1 (High)
- [ ] Persist diagnostic results to DB (currently state-only)
- [ ] Spaced retention checks
- [ ] Flesh out Parent/Admin/Sales sub-pages
- [ ] Replace Sales mock data with real CRM

### P2 (Medium)
- [ ] Real authentication (JWT or Google OAuth)
- [ ] Multiple classrooms
- [ ] Export/reporting features
- [ ] Achievement/badge system

## Technical Notes
- Sales pipeline data is MOCK (hardcoded in SalesHome.jsx)
- Diagnostic results are passed via react-router location.state (not persisted to DB)
- Diagnostic nodes: N01, N04, N05, N15, N17 (spread across key skills)
- Image generation uses OpenAI GPT Image 1 via emergentintegrations
- EMERGENT_LLM_KEY in backend/.env powers all AI features
